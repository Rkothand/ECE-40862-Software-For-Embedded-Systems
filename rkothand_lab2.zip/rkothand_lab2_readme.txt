videoLink: https://www.youtube.com/watch?v=pYOiIjDtvYc&ab_channel=RohithK
ADC pin is 34 because its an ADC channel 1
LED pin is 27 becuase its a normal GPIO
button pin is 38
