we use pin 14 for the scl because the new firmware for esp32 does not include i2c
we made applets to interact between ifttt and webhooks and google assistant to send json packages with the accelerometer 
when we arm the esp32 we set the neo pixel to green
when we detect motion we set the neo pixel to red momentarily and then back to green
when utilize the commands "lab on" to arm it and "lab off" to disarm it
youtube vid link: https://youtu.be/eJCJE5k0OUQ